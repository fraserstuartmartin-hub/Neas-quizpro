'use client'

import { useState, useEffect } from 'react'
import { DB, seedAdmin } from '@/lib/storage'
import type { Session, QuizConfig } from '@/lib/types'
import AuthScreen   from '@/components/AuthScreen'
import Dashboard    from '@/components/Dashboard'
import AdminDashboard from '@/components/AdminDashboard'
import QuizScreen   from '@/components/QuizScreen'
import ResultsScreen from '@/components/ResultsScreen'

type Screen = 'dashboard' | 'quiz' | 'results'

interface QuizResult {
  topic: string
  questions: QuizConfig['questions']
  answers: Record<string, { answer: string | null; correct: boolean; score: number }>
  score: number
}

export default function HomePage() {
  const [user,       setUser]       = useState<Session | null>(null)
  const [screen,     setScreen]     = useState<Screen>('dashboard')
  const [quizConfig, setQuizConfig] = useState<QuizConfig | null>(null)
  const [quizResult, setQuizResult] = useState<QuizResult | null>(null)
  const [hydrated,   setHydrated]   = useState(false)

  useEffect(() => {
    // Seed admin account and restore session after hydration
    seedAdmin(
      process.env.NEXT_PUBLIC_ADMIN_EMAIL    || 'fraser.stuart.martin@gmail.com',
      process.env.NEXT_PUBLIC_ADMIN_NAME     || 'Fraser Martin',
      process.env.NEXT_PUBLIC_ADMIN_PASSWORD || 'admin1234',
    )
    setUser(DB.session())
    setHydrated(true)
  }, [])

  if (!hydrated) return null // Prevent hydration mismatch

  const login = (session: Session) => {
    setUser(session)
    setScreen('dashboard')
  }

  const logout = () => {
    DB.saveSession(null)
    setUser(null)
    setScreen('dashboard')
    setQuizConfig(null)
    setQuizResult(null)
  }

  const startQuiz = (cfg: QuizConfig) => {
    setQuizConfig(cfg)
    setScreen('quiz')
  }

  const finishQuiz = (result: QuizResult) => {
    setQuizResult(result)
    setScreen('results')
  }

  const goHome = () => {
    setScreen('dashboard')
    setQuizConfig(null)
    setQuizResult(null)
  }

  if (!user)                            return <AuthScreen   onLogin={login} />
  if (user.role === 'admin')            return <AdminDashboard user={user} onLogout={logout} />
  if (screen === 'quiz' && quizConfig)  return <QuizScreen   config={quizConfig} user={user} onFinish={finishQuiz} onBack={goHome} />
  if (screen === 'results' && quizResult) return <ResultsScreen result={quizResult} onHome={goHome} />
  return <Dashboard user={user} onStart={startQuiz} onLogout={logout} />
}
