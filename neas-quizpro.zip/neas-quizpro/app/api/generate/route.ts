import { NextRequest, NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'
import type { GenerateRequest, Question } from '@/lib/types'

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

export async function POST(req: NextRequest) {
  try {
    const body: GenerateRequest = await req.json()
    const { topicPrompt, count } = body

    if (!topicPrompt || typeof topicPrompt !== 'string') {
      return NextResponse.json({ error: 'topicPrompt is required' }, { status: 400 })
    }
    if (!count || count < 1 || count > 20) {
      return NextResponse.json({ error: 'count must be between 1 and 20' }, { status: 400 })
    }

    const message = await anthropic.messages.create({
      model: 'claude-haiku-4-5-20251001',
      max_tokens: 2000,
      messages: [{
        role: 'user',
        content: `Generate ${count} quiz questions for a paramedic apprenticeship interview prep tool.

Candidate: Currently works as an Ambulance Support Practitioner (ASP) at the North East Ambulance Service (NEAS). Applying for a Paramedic Degree Apprenticeship. Has real frontline 999 experience supporting paramedics but is NOT yet a qualified paramedic. Questions must be pitched at apprenticeship interview level — testing awareness, values, motivation and basic principles, NOT advanced clinical knowledge.

Topic: "${topicPrompt}"

Mix: ~60% multiple_choice, ~40% short_answer

Return ONLY a valid JSON array, no markdown, no text outside the array:
[
  {"id":"q1","type":"multiple_choice","question":"...","options":["A","B","C","D"],"answer":"A","explanation":"..."},
  {"id":"q2","type":"short_answer","question":"...","answer":"key points expected","explanation":"..."}
]`,
      }],
    })

    const raw = message.content
      .filter(b => b.type === 'text')
      .map(b => (b as { type: 'text'; text: string }).text)
      .join('')

    const clean = raw
      .replace(/^```(?:json)?\s*/i, '')
      .replace(/```\s*$/i, '')
      .trim()

    const questions: Question[] = JSON.parse(clean)

    if (!Array.isArray(questions) || questions.length === 0) {
      throw new Error('Invalid response format from AI')
    }

    return NextResponse.json({ questions })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    console.error('[/api/generate]', message)
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
