import { NextRequest, NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'
import type { GradeRequest, GradeResponse } from '@/lib/types'

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

export async function POST(req: NextRequest) {
  try {
    const body: GradeRequest = await req.json()
    const { question, expected, userAnswer } = body

    if (!question || !expected || !userAnswer) {
      return NextResponse.json({ error: 'question, expected, and userAnswer are required' }, { status: 400 })
    }

    const message = await anthropic.messages.create({
      model: 'claude-haiku-4-5-20251001',
      max_tokens: 150,
      messages: [{
        role: 'user',
        content: `Grade this answer. Reply ONLY with valid JSON, no markdown.
Question: "${question}"
Expected key points: "${expected}"
Student answer: "${userAnswer}"
{"correct":true,"score":80,"feedback":"One sentence of constructive feedback."}`,
      }],
    })

    const raw = message.content
      .filter(b => b.type === 'text')
      .map(b => (b as { type: 'text'; text: string }).text)
      .join('')

    const clean = raw
      .replace(/^```(?:json)?\s*/i, '')
      .replace(/```\s*$/i, '')
      .trim()

    const result: GradeResponse = JSON.parse(clean)

    return NextResponse.json(result)
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    console.error('[/api/grade]', message)
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
