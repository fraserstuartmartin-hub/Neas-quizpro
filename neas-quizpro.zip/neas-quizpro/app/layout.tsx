import type { Metadata } from 'next'
import { T } from '@/lib/theme'

export const metadata: Metadata = {
  title: 'NEAS QuizPro — Paramedic Apprenticeship Interview Prep',
  description: 'AI-powered quiz platform for NEAS Ambulance Support Practitioners preparing for paramedic apprenticeship interviews.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body style={{ margin: 0, background: T.bg, fontFamily: "'Inter', sans-serif", WebkitFontSmoothing: 'antialiased' }}>
        <style>{`
          *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
          select { appearance: none; -webkit-appearance: none; }
          textarea { font-family: 'Inter', sans-serif; }
          ::-webkit-scrollbar { width: 5px; }
          ::-webkit-scrollbar-track { background: ${T.bg}; }
          ::-webkit-scrollbar-thumb { background: ${T.borderDk}; border-radius: 3px; }
          @keyframes fadeUp { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
          @keyframes spin   { to { transform: rotate(360deg); } }
        `}</style>
        {children}
      </body>
    </html>
  )
}
