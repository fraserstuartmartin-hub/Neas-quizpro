import type { User, Session, QuizProgress } from './types'

const KEYS = {
  users:    'qp_users',
  session:  'qp_session',
  progress: 'qp_progress',
} as const

function safeGet<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback
  try {
    const v = localStorage.getItem(key)
    return v ? (JSON.parse(v) as T) : fallback
  } catch {
    return fallback
  }
}

function safeSet(key: string, value: unknown): void {
  if (typeof window === 'undefined') return
  try { localStorage.setItem(key, JSON.stringify(value)) } catch {}
}

export const DB = {
  users:    ()  => safeGet<Record<string, User>>(KEYS.users, {}),
  session:  ()  => safeGet<Session | null>(KEYS.session, null),
  progress: ()  => safeGet<Record<string, QuizProgress>>(KEYS.progress, {}),

  saveUsers:    (v: Record<string, User>)          => safeSet(KEYS.users, v),
  saveSession:  (v: Session | null)                => safeSet(KEYS.session, v),
  saveProgress: (v: Record<string, QuizProgress>)  => safeSet(KEYS.progress, v),
}

/** Seed the admin account on first load (client-side only) */
export function seedAdmin(email: string, name: string, pass: string): void {
  const users = DB.users()
  if (!users[email]) {
    users[email] = { name, email, pass, role: 'admin', joined: Date.now() }
    DB.saveUsers(users)
  }
}
