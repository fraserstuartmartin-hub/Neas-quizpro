// ─── Question types ───────────────────────────────────────────
export type QuestionType = 'multiple_choice' | 'short_answer'

export interface Question {
  id: string
  type: QuestionType
  question: string
  options?: string[]   // multiple_choice only
  answer: string
  explanation: string
}

// ─── Answer / progress ───────────────────────────────────────
export interface Answer {
  answer: string | null
  correct: boolean
  score: number  // 0–1
}

export interface QuizProgress {
  user: string
  topic: string
  questions: Question[]
  timer: TimerMode
  timerVal: number
  currentIndex: number
  answers: Record<string, Answer>
  finished: boolean
  score?: number
  finishedAt?: number
}

// ─── Quiz config passed to QuizScreen ────────────────────────
export interface QuizConfig {
  quizId: string
  topic: string
  questions: Question[]
  timer: TimerMode
  timerVal: number
  resume?: boolean
}

// ─── Timer ───────────────────────────────────────────────────
export type TimerMode = 'none' | 'per_question' | 'overall'

// ─── User ────────────────────────────────────────────────────
export interface User {
  name: string
  email: string
  role: 'user' | 'admin'
  pass: string
  joined: number
}

export interface Session {
  name: string
  email: string
  role: 'user' | 'admin'
}

// ─── Topic ───────────────────────────────────────────────────
export interface TopicItem {
  label: string
  prompt: string
}

export interface TopicCategory {
  category: string
  accent: string
  items: TopicItem[]
}

// ─── API payloads ────────────────────────────────────────────
export interface GenerateRequest {
  topicPrompt: string
  count: number
}

export interface GradeRequest {
  question: string
  expected: string
  userAnswer: string
}

export interface GradeResponse {
  correct: boolean
  score: number
  feedback: string
}
