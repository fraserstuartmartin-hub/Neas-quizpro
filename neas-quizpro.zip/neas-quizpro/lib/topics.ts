import type { TopicCategory } from './types'

export const TOPICS: TopicCategory[] = [
  {
    category: 'NEAS & Organisation',
    accent: '#1D6BE5',
    items: [
      {
        label: 'The North East Ambulance Service',
        prompt: `The North East Ambulance Service (NEAS) — questions for an ASP applying for a paramedic degree apprenticeship who already works at NEAS.
Ask interview-style questions such as: what the four response categories (Cat 1–4) mean and why they matter, the difference between 999 emergency and 111 urgent calls, the geographic area NEAS covers, how NEAS fits into the NHS, what the candidate values about working for NEAS, and why they want to progress to become a paramedic.
Questions must feel like real panel interview questions — reflective and motivational, based on the day-to-day experience of a frontline support worker. Do NOT ask organisational strategy or leadership questions.`,
      },
      {
        label: 'NEAS Values',
        prompt: `NEAS core values (caring, open, respect, excellence) — behavioural interview questions for an ASP applying for a paramedic apprenticeship.
Ask questions like: what does each value mean to them personally, describe a time they demonstrated a value in their current ASP role, why these values matter when treating patients, and how they would respond if they saw a colleague not living the values.
All questions must be reflective and behavioural — exactly the type asked at a real NHS apprenticeship panel interview. No strategic or leadership framing.`,
      },
    ],
  },
  {
    category: 'Professional Standards',
    accent: '#7C3AED',
    items: [
      {
        label: 'HCPC Standards of Conduct',
        prompt: 'HCPC Standards of Conduct, Performance and Ethics — introductory awareness for an ASP applying for a paramedic apprenticeship. Cover what the key standards mean (honesty, patient safety, raising concerns, maintaining skills), why they exist, and how they relate to working as a paramedic. Test awareness and understanding, not expert application.',
      },
      {
        label: 'HCPC Standards of Proficiency',
        prompt: 'HCPC Standards of Proficiency for paramedics — introductory awareness for an ASP apprenticeship applicant. Cover what it means to be a registered paramedic, why proficiency standards protect patients, and the difference between being registered and unregistered. Keep at awareness level.',
      },
      {
        label: 'Professional Development & Reflective Practice',
        prompt: 'Reflective practice and CPD for someone starting a paramedic apprenticeship. Cover what reflection means, why it matters in healthcare, the Gibbs reflective cycle in simple terms, the importance of learning from experience on the job, and how CPD supports growth. Pitch at apprentice level.',
      },
    ],
  },
  {
    category: 'Joint Working & Frameworks',
    accent: '#059669',
    items: [
      {
        label: 'JESIP Principles',
        prompt: 'JESIP Joint Emergency Services Interoperability Principles — introductory level for an ASP applying for a paramedic apprenticeship. Cover what JESIP stands for, the five principles in plain terms (co-locate, communicate, co-ordinate, jointly understand risk, shared situational awareness), and why joint working between emergency services matters at major incidents.',
      },
      {
        label: 'JESIP Joint Decision Model',
        prompt: 'The JESIP Joint Decision Model — introductory awareness for an ASP apprenticeship applicant. Cover what the JDM is, its main steps in simple terms, and why a shared decision-making framework helps emergency services work together effectively. Pitch at awareness level.',
      },
      {
        label: 'SBAR & ATMIST Handover',
        prompt: 'SBAR and ATMIST handover tools — introductory level for an ASP applying for a paramedic apprenticeship. Cover what each acronym stands for, when each is used, the purpose of structured handover, and why clear communication at patient handover is critical for safety.',
      },
    ],
  },
  {
    category: 'Legislation & Ethics',
    accent: '#D97706',
    items: [
      {
        label: 'Care Act 2014',
        prompt: 'Care Act 2014 basics — for an ASP applying for a paramedic apprenticeship. Cover the wellbeing principle, safeguarding duties for adults, the duty of care, and why this is relevant to ambulance work. Pitch at introductory awareness level.',
      },
      {
        label: 'Mental Capacity Act 2005',
        prompt: 'Mental Capacity Act 2005 — introductory level for an ASP applying for a paramedic apprenticeship. Cover the five key principles in plain terms, what mental capacity means, why it matters in ambulance care, and basic awareness of best interest decisions.',
      },
      {
        label: 'Medical Ethics & Consent',
        prompt: 'Medical ethics and consent — introductory level for an ASP applying for a paramedic apprenticeship. Cover the four pillars of ethics in plain terms (autonomy, beneficence, non-maleficence, justice), what valid consent means, why it matters, and Gillick competence at an awareness level.',
      },
      {
        label: 'Equality, Diversity & Inclusion',
        prompt: 'Equality, Diversity and Inclusion for an ASP applying for a paramedic apprenticeship. Cover the Equality Act 2010, the nine protected characteristics, what treating people with dignity means in ambulance practice, and why EDI matters in healthcare. Pitch at introductory awareness level.',
      },
    ],
  },
  {
    category: 'Safeguarding',
    accent: '#DC2626',
    items: [
      {
        label: 'Safeguarding Adults',
        prompt: "Safeguarding adults — introductory level for an ASP applying for a paramedic apprenticeship. Cover the types of abuse, signs to look out for, why safeguarding matters, the duty to report, and the ambulance service's role in protecting vulnerable adults.",
      },
      {
        label: 'Safeguarding Children',
        prompt: 'Safeguarding children — introductory level for an ASP applying for a paramedic apprenticeship. Cover types of abuse, signs of concern, the duty to report and who to report to, and why paramedics play an important role in protecting children.',
      },
      {
        label: 'Safeguarding — Adults & Children',
        prompt: 'Safeguarding adults and children combined — introductory awareness for an ASP applying for a paramedic apprenticeship. Cover the key principles of safeguarding, types of abuse across both groups, the duty to report, and how ambulance crews contribute to keeping vulnerable people safe.',
      },
    ],
  },
  {
    category: 'Clinical Knowledge',
    accent: '#DB2777',
    items: [
      {
        label: 'Basic Life Support & CPR',
        prompt: 'Basic Life Support and CPR — for an ASP applying for a paramedic apprenticeship who has likely completed BLS training. Cover the adult BLS sequence (DRS ABC / DR ABCD), compression rate and depth, rescue breaths ratio, AED use steps, the chain of survival, and why early CPR matters.',
      },
      {
        label: 'Airway Management',
        prompt: 'Airway management basics — for an ASP applying for a paramedic apprenticeship. Cover recognising an airway problem, head tilt/chin lift and jaw thrust techniques, the recovery position, when and why to use suction, and the importance of a clear airway.',
      },
      {
        label: 'Vital Signs & Patient Assessment',
        prompt: 'Vital signs and basic patient assessment — for an ASP applying for a paramedic apprenticeship. Cover normal adult ranges for pulse, respiratory rate, blood pressure, oxygen saturations and temperature, what the ABCDE approach is and why it is used, and the importance of accurate and timely observations.',
      },
    ],
  },
  {
    category: 'Ethics, Consent & Law',
    accent: '#EA580C',
    items: [
      {
        label: 'Gillick Competence & Fraser Guidelines',
        prompt: 'Gillick competence and Fraser guidelines — introductory awareness for an ASP applying for a paramedic apprenticeship. Cover what Gillick competence means, how it differs from Fraser guidelines, and why understanding capacity in under-16s matters in ambulance care.',
      },
      {
        label: 'Mental Capacity & Refusal of Treatment',
        prompt: 'Mental capacity and refusal of treatment — introductory level for an ASP applying for a paramedic apprenticeship. Cover what it means to have mental capacity, how you approach a patient refusing treatment, why patient autonomy is important, and when it might be appropriate to seek further support.',
      },
    ],
  },
  {
    category: 'Communication & Handover',
    accent: '#0891B2',
    items: [
      {
        label: 'SBAR Handover Tool',
        prompt: 'SBAR (Situation, Background, Assessment, Recommendation) — for an ASP applying for a paramedic apprenticeship. Cover what each element means, how to structure a handover using SBAR, why structured communication improves patient safety, and a simple worked example.',
      },
      {
        label: 'ATMIST Handover Tool',
        prompt: 'ATMIST (Age, Time, Mechanism, Injuries, Signs, Treatment) — for an ASP applying for a paramedic apprenticeship. Cover what each element stands for, when ATMIST is used (trauma), and why a structured format for trauma handover helps the receiving team.',
      },
      {
        label: 'Therapeutic Communication',
        prompt: 'Therapeutic communication — for an ASP applying for a paramedic apprenticeship. Cover what therapeutic communication means, the importance of active listening, empathy, clear and simple language, non-verbal communication, and how good communication improves patient experience and outcomes.',
      },
    ],
  },
  {
    category: 'Wellbeing & Development',
    accent: '#65A30D',
    items: [
      {
        label: 'Personal Resilience & Wellbeing',
        prompt: 'Personal resilience and wellbeing — for an ASP applying for a paramedic apprenticeship. Cover what resilience means, why ambulance work can be emotionally and physically demanding, the importance of looking after your own health and wellbeing, peer support schemes, and knowing when and how to seek help.',
      },
    ],
  },
  {
    category: 'NHS Strategy & Policy',
    accent: '#4F46E5',
    items: [
      {
        label: 'NHS 10 Year Plan',
        prompt: 'The NHS 10 Year Plan (2025) — introductory awareness for an ASP applying for a paramedic apprenticeship. Cover the key themes (neighbourhood health, prevention, digital/AI, mental health, workforce), what the plan means for ambulance services, and why understanding NHS strategy matters for someone starting a paramedic career.',
      },
      {
        label: 'NHS Long Term Plan',
        prompt: 'NHS Long Term Plan 2019 — introductory awareness for an ASP applying for a paramedic apprenticeship. Cover the key goals, what prevention means in the NHS context, mental health investment, and why understanding NHS priorities is relevant for someone starting a paramedic apprenticeship.',
      },
      {
        label: 'Integrated Care Systems',
        prompt: 'Integrated Care Systems (ICS) — introductory awareness for an ASP applying for a paramedic apprenticeship. Cover what an ICS is, why health and care organisations work together, how NEAS fits within the wider health and care system, and what this means for patients.',
      },
    ],
  },
]
