'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { DB } from '@/lib/storage'
import { T } from '@/lib/theme'
import type { Session, QuizConfig, Question, Answer } from '@/lib/types'
import { Btn, Pill, Spinner, TextInput } from '@/components/ui'

interface QuizResult {
  topic: string
  questions: Question[]
  answers: Record<string, Answer>
  score: number
}

export default function QuizScreen({
  config, user, onFinish, onBack,
}: {
  config: QuizConfig
  user: Session
  onFinish: (r: QuizResult) => void
  onBack: () => void
}) {
  const { quizId, topic, questions, timer, timerVal, resume: isResume } = config

  const saved = isResume ? (DB.progress()[quizId] || {}) : {}

  const [index,      setIndex]      = useState<number>((saved as { currentIndex?: number }).currentIndex ?? 0)
  const [answers,    setAnswers]    = useState<Record<string, Answer>>((saved as { answers?: Record<string, Answer> }).answers ?? {})
  const [selected,   setSelected]   = useState<string | null>(null)
  const [shortInput, setShortInput] = useState('')
  const [feedback,   setFeedback]   = useState<{ correct: boolean; explanation?: string; feedback: string } | null>(null)
  const [grading,    setGrading]    = useState(false)
  const [perTime,    setPerTime]    = useState<number | null>(timer === 'per_question' ? timerVal : null)
  const [totalTime,  setTotalTime]  = useState<number | null>(timer === 'overall' ? timerVal * 60 : null)

  const perRef    = useRef<ReturnType<typeof setInterval> | null>(null)
  const totalRef  = useRef<ReturnType<typeof setInterval> | null>(null)
  const answersRef   = useRef(answers)
  const indexRef     = useRef(index)
  const questionsRef = useRef(questions)

  useEffect(() => { answersRef.current   = answers },   [answers])
  useEffect(() => { indexRef.current     = index },     [index])
  useEffect(() => { questionsRef.current = questions }, [questions])

  const q        = questions[index] ?? null
  const answered = q ? !!answers[q.id] : false

  // Persist progress
  useEffect(() => {
    const all = DB.progress()
    all[quizId] = { user: user.email, topic, questions, timer, timerVal, currentIndex: index, answers, finished: false }
    DB.saveProgress(all)
  }, [index, answers]) // eslint-disable-line react-hooks/exhaustive-deps

  const finishQuiz = useCallback(() => {
    if (perRef.current)   clearInterval(perRef.current)
    if (totalRef.current) clearInterval(totalRef.current)
    const ans   = answersRef.current
    const score = Object.values(ans).reduce((a, v) => a + (v.score || 0), 0)
    const all   = DB.progress()
    all[quizId] = { ...all[quizId], finished: true, score, finishedAt: Date.now(), answers: ans }
    DB.saveProgress(all)
    onFinish({ topic, questions: questionsRef.current, answers: ans, score })
  }, [quizId, topic, onFinish]) // eslint-disable-line react-hooks/exhaustive-deps

  // Overall timer — start once
  useEffect(() => {
    if (timer !== 'overall') return
    totalRef.current = setInterval(() => {
      setTotalTime(t => {
        if (t == null || t <= 1) { clearInterval(totalRef.current!); finishQuiz(); return 0 }
        return t - 1
      })
    }, 1000)
    return () => { if (totalRef.current) clearInterval(totalRef.current) }
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  // Per-question timer — restart each question
  useEffect(() => {
    if (perRef.current) clearInterval(perRef.current)
    if (timer !== 'per_question' || !q || answered) return
    setPerTime(timerVal)
    perRef.current = setInterval(() => {
      setPerTime(t => {
        if (t == null || t <= 1) {
          clearInterval(perRef.current!)
          const curQ = questionsRef.current[indexRef.current]
          if (curQ && !answersRef.current[curQ.id]) {
            setFeedback({ correct: false, explanation: curQ.explanation, feedback: "Time's up — no answer recorded." })
            setAnswers(prev => ({ ...prev, [curQ.id]: { answer: null, correct: false, score: 0 } }))
          }
          return 0
        }
        return t - 1
      })
    }, 1000)
    return () => { if (perRef.current) clearInterval(perRef.current) }
  }, [index]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (answered && perRef.current) clearInterval(perRef.current)
  }, [answered])

  const submitMC = (opt: string) => {
    if (!q || answered) return
    if (perRef.current) clearInterval(perRef.current)
    const correct = opt === q.answer
    setSelected(opt)
    setFeedback({ correct, explanation: q.explanation, feedback: correct ? 'Correct.' : `The correct answer is: ${q.answer}` })
    setAnswers(prev => ({ ...prev, [q.id]: { answer: opt, correct, score: correct ? 1 : 0 } }))
  }

  const submitShort = async () => {
    if (!q || !shortInput.trim() || grading || answered) return
    if (perRef.current) clearInterval(perRef.current)
    setGrading(true)
    try {
      const res    = await fetch('/api/grade', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ question: q.question, expected: q.answer, userAnswer: shortInput }) })
      const result = await res.json()
      const score  = (result.score ?? (result.correct ? 100 : 0)) / 100
      setFeedback({ correct: result.correct, explanation: q.explanation, feedback: result.feedback ?? '' })
      setAnswers(prev => ({ ...prev, [q.id]: { answer: shortInput, correct: result.correct, score } }))
    } catch {
      setFeedback({ correct: false, explanation: q.explanation, feedback: 'Grading unavailable — marked as incorrect.' })
      setAnswers(prev => ({ ...prev, [q.id]: { answer: shortInput, correct: false, score: 0 } }))
    }
    setGrading(false)
  }

  const nextQuestion = () => {
    setFeedback(null); setSelected(null); setShortInput('')
    if (index + 1 >= questions.length) finishQuiz()
    else setIndex(i => i + 1)
  }

  if (!q) return null

  const progressPct = Math.round((index / questions.length) * 100)

  return (
    <div style={{ minHeight: '100vh', background: T.bg, display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <div style={{ background: T.navy, color: '#fff', padding: '0 20px', display: 'flex', alignItems: 'center', gap: 14, height: 52, flexShrink: 0 }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#ffffff66', cursor: 'pointer', fontSize: 18, padding: '4px 6px', lineHeight: 1 }}>←</button>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
            <span style={{ fontSize: 12, color: '#ffffffaa', fontWeight: 500 }}>{topic}</span>
            <span style={{ fontSize: 12, color: '#ffffffaa', fontFamily: T.mono }}>Q{index + 1} / {questions.length}</span>
          </div>
          <div style={{ height: 3, background: '#ffffff20', borderRadius: 2 }}>
            <div style={{ height: '100%', width: `${progressPct}%`, background: '#4f8ef7', borderRadius: 2, transition: 'width .4s ease' }} />
          </div>
        </div>
        {timer === 'overall' && totalTime !== null && (
          <span style={{ fontFamily: T.mono, fontSize: 14, color: totalTime < 30 ? '#f87171' : '#fbbf24', minWidth: 50, textAlign: 'right' }}>
            {Math.floor(totalTime / 60)}:{String(totalTime % 60).padStart(2, '0')}
          </span>
        )}
      </div>

      {/* Body */}
      <div style={{ flex: 1, maxWidth: 720, width: '100%', margin: '0 auto', padding: '32px 20px 60px' }}>

        {/* Per-question timer bar */}
        {timer === 'per_question' && perTime !== null && !answered && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 20 }}>
            <div style={{ flex: 1, height: 3, background: T.border, borderRadius: 3 }}>
              <div style={{ height: '100%', width: `${(perTime / timerVal) * 100}%`, background: perTime < 6 ? T.red : T.accent, borderRadius: 3, transition: 'width 1s linear' }} />
            </div>
            <span style={{ fontFamily: T.mono, fontSize: 12, color: perTime < 6 ? T.red : T.muted, minWidth: 28, fontWeight: 600 }}>{perTime}s</span>
          </div>
        )}

        <div style={{ animation: 'fadeUp .3s ease' }}>
          <div style={{ marginBottom: 14 }}>
            <Pill color={q.type === 'multiple_choice' ? T.accent : '#7C3AED'}>
              {q.type === 'multiple_choice' ? 'Multiple Choice' : 'Short Answer'}
            </Pill>
          </div>

          <h2 style={{ fontSize: 19, fontWeight: 600, lineHeight: 1.55, color: T.text, marginBottom: 24, letterSpacing: '-.01em' }}>{q.question}</h2>

          {/* Multiple choice */}
          {q.type === 'multiple_choice' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
              {(q.options ?? []).map((opt, i) => {
                let bg = T.surface, border = T.border, color = T.text, icon = String.fromCharCode(65 + i)
                if (answered) {
                  if (opt === q.answer)                          { bg = T.greenBg; border = T.green; color = T.green; icon = '✓' }
                  else if (opt === selected && opt !== q.answer) { bg = T.redBg;   border = T.red;   color = T.red;   icon = '✗' }
                  else                                           { color = T.muted }
                }
                return (
                  <button key={`${opt}-${i}`} onClick={() => submitMC(opt)} disabled={answered}
                    style={{ background: bg, border: `1.5px solid ${border}`, borderRadius: 8, padding: '13px 16px', textAlign: 'left', fontFamily: 'inherit', fontSize: 14, color, cursor: answered ? 'default' : 'pointer', transition: 'all .15s', display: 'flex', alignItems: 'center', gap: 10 }}
                    onMouseEnter={e => { if (!answered) { (e.currentTarget as HTMLButtonElement).style.borderColor = T.accent; (e.currentTarget as HTMLButtonElement).style.boxShadow = `0 0 0 3px ${T.accent}18` } }}
                    onMouseLeave={e => { if (!answered) { (e.currentTarget as HTMLButtonElement).style.borderColor = border; (e.currentTarget as HTMLButtonElement).style.boxShadow = 'none' } }}
                  >
                    <span style={{ fontFamily: T.mono, fontSize: 12, color: answered ? color : T.muted, minWidth: 20, fontWeight: 700 }}>{icon}</span>
                    <span>{opt}</span>
                  </button>
                )
              })}
            </div>
          )}

          {/* Short answer */}
          {q.type === 'short_answer' && (
            <div>
              <TextInput textarea value={shortInput}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setShortInput(e.target.value)}
                disabled={answered || grading}
                placeholder="Type your answer here…"
                rows={5}
                style={{ background: answered ? T.card : '#fff', border: `1.5px solid ${T.border}` }}
              />
              {!answered && (
                <Btn onClick={submitShort} disabled={grading || !shortInput.trim()} style={{ marginTop: 12 }}>
                  {grading ? <><Spinner color="#fff" size={15} /> Grading…</> : 'Submit Answer'}
                </Btn>
              )}
            </div>
          )}

          {/* Feedback */}
          {feedback && (
            <div style={{ marginTop: 18, background: feedback.correct ? T.greenBg : T.redBg, border: `1px solid ${feedback.correct ? T.greenBd : T.redBd}`, borderRadius: 8, padding: '16px 18px', animation: 'fadeUp .25s ease' }}>
              <div style={{ fontWeight: 700, color: feedback.correct ? T.green : T.red, marginBottom: 6, fontSize: 14 }}>
                {feedback.correct ? '✓ Correct' : '✗ Incorrect'}
              </div>
              {feedback.feedback && <p style={{ color: T.text, fontSize: 13, lineHeight: 1.65, marginBottom: feedback.explanation ? 8 : 0 }}>{feedback.feedback}</p>}
              {feedback.explanation && (
                <>
                  <div style={{ height: 1, background: feedback.correct ? T.greenBd : T.redBd, margin: '10px 0' }} />
                  <p style={{ color: T.sub, fontSize: 13, lineHeight: 1.65 }}><strong>Explanation:</strong> {feedback.explanation}</p>
                </>
              )}
            </div>
          )}

          {answered && (
            <div style={{ marginTop: 18 }}>
              <Btn onClick={nextQuestion} full size="lg">
                {index + 1 >= questions.length ? 'View Results →' : 'Next Question →'}
              </Btn>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
