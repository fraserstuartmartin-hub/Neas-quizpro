'use client'

import { CSSProperties, ReactNode } from 'react'
import { T } from '@/lib/theme'

// ─── Spinner ─────────────────────────────────────────────────
export function Spinner({ size = 18, color = T.accent }: { size?: number; color?: string }) {
  return (
    <span style={{
      display: 'inline-block', width: size, height: size,
      border: `2px solid ${T.border}`, borderTopColor: color,
      borderRadius: '50%', animation: 'spin .7s linear infinite', flexShrink: 0,
    }} />
  )
}

// ─── Pill badge ───────────────────────────────────────────────
export function Pill({ children, color = T.accent, bg }: { children: ReactNode; color?: string; bg?: string }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center',
      background: bg || color + '18', color,
      border: `1px solid ${color}44`, borderRadius: 4,
      padding: '2px 8px', fontSize: 11, fontWeight: 600,
      fontFamily: T.mono, letterSpacing: '.03em', whiteSpace: 'nowrap',
    }}>
      {children}
    </span>
  )
}

// ─── Score badge ──────────────────────────────────────────────
export function ScoreBadge({ pct }: { pct: number }) {
  const color = pct >= 70 ? T.green  : pct >= 45 ? T.amber  : T.red
  const bg    = pct >= 70 ? T.greenBg : pct >= 45 ? T.amberBg : T.redBg
  const bd    = pct >= 70 ? T.greenBd : pct >= 45 ? T.amberBd : T.redBd
  return (
    <span style={{
      background: bg, color, border: `1px solid ${bd}`,
      borderRadius: 5, padding: '3px 10px',
      fontSize: 13, fontFamily: T.mono, fontWeight: 700,
    }}>
      {pct}%
    </span>
  )
}

// ─── Button ───────────────────────────────────────────────────
type BtnVariant = 'primary' | 'ghost' | 'danger'
type BtnSize    = 'sm' | 'md' | 'lg'

export function Btn({
  children, onClick, variant = 'primary', disabled = false,
  full = false, size = 'md', style: sx = {},
}: {
  children: ReactNode; onClick?: () => void; variant?: BtnVariant
  disabled?: boolean; full?: boolean; size?: BtnSize; style?: CSSProperties
}) {
  const pad = { sm: '6px 14px', md: '9px 20px', lg: '11px 26px' }
  const fz  = { sm: 13, md: 14, lg: 15 }
  const vars: Record<BtnVariant, CSSProperties> = {
    primary: { background: T.accent, color: '#fff', border: 'none' },
    ghost:   { background: 'transparent', color: T.sub, border: `1px solid ${T.border}` },
    danger:  { background: T.redBg, color: T.red, border: `1px solid ${T.redBd}` },
  }
  return (
    <button
      onClick={disabled ? undefined : onClick}
      style={{
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 7,
        borderRadius: 6, fontFamily: 'inherit', fontWeight: 600,
        cursor: disabled ? 'not-allowed' : 'pointer', transition: 'all .15s',
        width: full ? '100%' : 'auto', opacity: disabled ? .55 : 1,
        padding: pad[size], fontSize: fz[size],
        ...vars[variant], ...sx,
      }}
      onMouseEnter={e => { if (!disabled && variant === 'primary') (e.currentTarget as HTMLButtonElement).style.background = T.accentHv }}
      onMouseLeave={e => { if (!disabled && variant === 'primary') (e.currentTarget as HTMLButtonElement).style.background = T.accent }}
    >
      {children}
    </button>
  )
}

// ─── Text input / textarea ────────────────────────────────────
export function TextInput({
  label, error, textarea = false, rows = 4, ...props
}: {
  label?: string; error?: string; textarea?: boolean; rows?: number
  [key: string]: unknown
}) {
  const shared: CSSProperties = {
    background: '#fff', border: `1px solid ${error ? T.red : T.border}`,
    borderRadius: 6, padding: '10px 13px', color: T.text,
    fontFamily: 'inherit', fontSize: 14, outline: 'none',
    width: '100%', transition: 'border .15s',
    ...(props.style as CSSProperties || {}),
  }
  const onFocus = (e: React.FocusEvent<HTMLElement>) => {
    ;(e.target as HTMLElement).style.borderColor = T.accent
    ;(e.target as HTMLElement).style.boxShadow = `0 0 0 3px ${T.accent}18`
  }
  const onBlur = (e: React.FocusEvent<HTMLElement>) => {
    ;(e.target as HTMLElement).style.borderColor = error ? T.red : T.border
    ;(e.target as HTMLElement).style.boxShadow = 'none'
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { style: _s, ...rest } = props
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
      {label && <label style={{ fontSize: 13, fontWeight: 500, color: T.sub }}>{label}</label>}
      {textarea
        ? <textarea {...(rest as React.TextareaHTMLAttributes<HTMLTextAreaElement>)} rows={rows} style={{ ...shared, resize: 'vertical' }} onFocus={onFocus} onBlur={onBlur} />
        : <input   {...(rest as React.InputHTMLAttributes<HTMLInputElement>)}        style={shared}                                                               onFocus={onFocus} onBlur={onBlur} />
      }
      {error && <span style={{ fontSize: 12, color: T.red }}>{error}</span>}
    </div>
  )
}

// ─── Card ─────────────────────────────────────────────────────
export function Card({ children, style: sx = {} }: { children: ReactNode; style?: CSSProperties }) {
  return (
    <div style={{ background: T.surface, border: `1px solid ${T.border}`, borderRadius: 8, ...sx }}>
      {children}
    </div>
  )
}

// ─── TopBar ───────────────────────────────────────────────────
export function TopBar({
  name, onLogout, isAdmin = false,
}: { name: string; onLogout: () => void; isAdmin?: boolean }) {
  return (
    <div style={{
      background: T.navy, color: '#fff', padding: '0 24px',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      height: 56, flexShrink: 0,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <span>🚑</span>
        <span style={{ fontWeight: 700, fontSize: 15 }}>NEAS QuizPro</span>
        {isAdmin && (
          <span style={{ fontSize: 10, background: '#fff3', borderRadius: 3, padding: '2px 7px', fontWeight: 700, letterSpacing: '.05em' }}>
            ADMIN
          </span>
        )}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <span style={{ fontSize: 13, color: '#ffffffaa' }}>{name}</span>
        <button onClick={onLogout} style={{
          background: '#ffffff18', border: '1px solid #ffffff30', borderRadius: 5,
          color: '#ffffffcc', fontSize: 12, fontWeight: 600, padding: '5px 12px',
          cursor: 'pointer', fontFamily: 'inherit',
        }}>
          Sign out
        </button>
      </div>
    </div>
  )
}
