'use client'

import { useState } from 'react'
import { DB } from '@/lib/storage'
import { T } from '@/lib/theme'
import type { Session } from '@/lib/types'
import { Card, Pill, ScoreBadge, TextInput, TopBar } from '@/components/ui'

export default function AdminDashboard({ user, onLogout }: { user: Session; onLogout: () => void }) {
  const [search,   setSearch]   = useState('')
  const [expanded, setExpanded] = useState<string | null>(null)

  const users    = DB.users()
  const progress = DB.progress()

  const userStats = Object.values(users)
    .filter(u => u.role !== 'admin')
    .map(u => {
      const all    = Object.values(progress).filter(q => q.user === u.email)
      const done   = all.filter(q => q.finished)
      const active = all.filter(q => !q.finished)
      const avg    = done.length
        ? Math.round(done.reduce((s, q) => s + Math.round(((q.score ?? 0) / q.questions.length) * 100), 0) / done.length)
        : null
      return { ...u, done, active, avg, topics: [...new Set(done.map(q => q.topic))] }
    })

  const filtered = userStats.filter(u =>
    u.name.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase())
  )

  const totalDone  = userStats.reduce((s, u) => s + u.done.length, 0)
  const withScores = userStats.filter(u => u.avg !== null)
  const globalAvg  = withScores.length ? Math.round(withScores.reduce((s, u) => s + (u.avg ?? 0), 0) / withScores.length) : null

  return (
    <div style={{ minHeight: '100vh', background: T.bg, display: 'flex', flexDirection: 'column' }}>
      <TopBar name={user.name} onLogout={onLogout} isAdmin />

      <div style={{ maxWidth: 1100, width: '100%', margin: '0 auto', padding: '32px 24px 80px' }}>

        <div style={{ marginBottom: 28, animation: 'fadeUp .3s ease' }}>
          <h2 style={{ fontSize: 22, fontWeight: 700, color: T.navy }}>User Performance Overview</h2>
          <p style={{ color: T.sub, fontSize: 14, marginTop: 4 }}>All registered learners and their quiz results.</p>
        </div>

        {/* Summary cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(175px,1fr))', gap: 12, marginBottom: 28, animation: 'fadeUp .35s ease' }}>
          {[
            { label: 'Registered Users',   value: userStats.length,                               icon: '👤' },
            { label: 'Active Learners',    value: userStats.filter(u => u.done.length > 0).length, icon: '✅' },
            { label: 'Total Completions',  value: totalDone,                                       icon: '📋' },
            { label: 'Platform Avg Score', value: globalAvg != null ? `${globalAvg}%` : '—',      icon: '📊' },
          ].map(s => (
            <Card key={s.label} style={{ padding: '18px 20px' }}>
              <div style={{ fontSize: 22, marginBottom: 8 }}>{s.icon}</div>
              <div style={{ fontSize: 28, fontWeight: 700, color: T.navy, fontFamily: T.mono }}>{s.value}</div>
              <div style={{ fontSize: 12, color: T.muted, marginTop: 3, fontWeight: 500 }}>{s.label}</div>
            </Card>
          ))}
        </div>

        {/* Search */}
        <div style={{ marginBottom: 14 }}>
          <TextInput placeholder="Search by name or email…" value={search} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearch(e.target.value)} style={{ maxWidth: 340 }} />
        </div>

        {/* Table */}
        <Card style={{ overflow: 'hidden', marginBottom: 32, animation: 'fadeUp .4s ease' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1.6fr 70px 70px 100px 1fr', gap: 12, padding: '10px 20px', background: T.card, borderBottom: `1px solid ${T.border}`, fontSize: 11, fontWeight: 700, color: T.muted, letterSpacing: '.06em', textTransform: 'uppercase' }}>
            <span>User</span><span>Email</span><span>Done</span><span>Active</span><span>Avg Score</span><span>Topics</span>
          </div>

          {filtered.length === 0 && (
            <div style={{ padding: '40px 20px', textAlign: 'center', color: T.muted, fontSize: 14 }}>
              {userStats.length === 0 ? 'No users registered yet.' : 'No results match your search.'}
            </div>
          )}

          {filtered.map((u, i) => (
            <div key={u.email}>
              <div
                onClick={() => u.done.length > 0 && setExpanded(expanded === u.email ? null : u.email)}
                style={{ display: 'grid', gridTemplateColumns: '2fr 1.6fr 70px 70px 100px 1fr', gap: 12, padding: '14px 20px', borderBottom: `1px solid ${T.border}`, alignItems: 'center', cursor: u.done.length > 0 ? 'pointer' : 'default', transition: 'background .12s', animation: `fadeUp ${.4 + i * .04}s ease` }}
                onMouseEnter={e => { if (u.done.length > 0) (e.currentTarget as HTMLDivElement).style.background = T.card }}
                onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.background = 'transparent' }}
              >
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{u.name}</div>
                  <div style={{ fontSize: 11, color: T.muted, marginTop: 2 }}>
                    Joined {new Date(u.joined).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </div>
                </div>
                <div style={{ fontSize: 13, color: T.sub, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{u.email}</div>
                <div style={{ fontFamily: T.mono, fontWeight: 700, fontSize: 15, color: T.navy }}>{u.done.length}</div>
                <div style={{ fontFamily: T.mono, fontWeight: 600, fontSize: 14, color: u.active.length > 0 ? T.amber : T.muted }}>{u.active.length}</div>
                <div>{u.avg != null ? <ScoreBadge pct={u.avg} /> : <span style={{ color: T.muted, fontSize: 13 }}>—</span>}</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, alignItems: 'center' }}>
                  {u.topics.length === 0
                    ? <span style={{ fontSize: 12, color: T.muted }}>None yet</span>
                    : u.topics.slice(0, 2).map(t => <Pill key={t} color={T.accent}>{t.length > 18 ? t.slice(0, 16) + '…' : t}</Pill>)
                  }
                  {u.topics.length > 2 && <Pill color={T.muted}>+{u.topics.length - 2}</Pill>}
                  {u.done.length > 0 && <span style={{ marginLeft: 'auto', fontSize: 11, color: T.muted }}>{expanded === u.email ? '▴' : '▾'}</span>}
                </div>
              </div>

              {/* Expanded quiz detail */}
              {expanded === u.email && (
                <div style={{ background: T.card, borderBottom: `1px solid ${T.border}`, padding: '14px 20px 18px' }}>
                  <p style={{ fontSize: 11, fontWeight: 700, color: T.muted, textTransform: 'uppercase', letterSpacing: '.06em', marginBottom: 10 }}>Completed Quizzes</p>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(200px,1fr))', gap: 8 }}>
                    {u.done.map((q, qi) => {
                      const pct = Math.round(((q.score ?? 0) / q.questions.length) * 100)
                      return (
                        <div key={qi} style={{ background: '#fff', border: `1px solid ${T.border}`, borderRadius: 7, padding: '10px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8 }}>
                          <div>
                            <div style={{ fontSize: 13, fontWeight: 600 }}>{q.topic}</div>
                            <div style={{ fontSize: 11, color: T.muted, marginTop: 2 }}>{q.questions.length} questions</div>
                          </div>
                          <ScoreBadge pct={pct} />
                        </div>
                      )
                    })}
                  </div>
                </div>
              )}
            </div>
          ))}
        </Card>
      </div>
    </div>
  )
}
