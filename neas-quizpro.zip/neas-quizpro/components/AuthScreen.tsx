'use client'

import { useState } from 'react'
import { DB } from '@/lib/storage'
import { T } from '@/lib/theme'
import type { Session } from '@/lib/types'
import { Btn, TextInput, Card } from '@/components/ui'

export default function AuthScreen({ onLogin }: { onLogin: (s: Session) => void }) {
  const [mode,  setMode]  = useState<'login' | 'register'>('login')
  const [name,  setName]  = useState('')
  const [email, setEmail] = useState('')
  const [pass,  setPass]  = useState('')
  const [err,   setErr]   = useState('')

  const submit = () => {
    setErr('')
    const users = DB.users()
    const key   = email.trim().toLowerCase()

    if (mode === 'login') {
      const u = users[key]
      if (!u || u.pass !== pass) { setErr('Invalid email or password.'); return }
      const session: Session = { name: u.name, email: u.email, role: u.role || 'user' }
      DB.saveSession(session)
      onLogin(session)
    } else {
      if (!name.trim())    { setErr('Full name is required.'); return }
      if (!key)            { setErr('Email is required.'); return }
      if (pass.length < 6) { setErr('Password must be at least 6 characters.'); return }
      if (users[key])      { setErr('An account with this email already exists.'); return }
      users[key] = { name: name.trim(), email: key, pass, role: 'user', joined: Date.now() }
      DB.saveUsers(users)
      const session: Session = { name: name.trim(), email: key, role: 'user' }
      DB.saveSession(session)
      onLogin(session)
    }
  }

  return (
    <div style={{ minHeight: '100vh', background: T.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div style={{ width: '100%', maxWidth: 420, animation: 'fadeUp .4s ease' }}>
        <div style={{ textAlign: 'center', marginBottom: 28 }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: 52, height: 52, background: T.navy, borderRadius: 12, fontSize: 24, marginBottom: 14 }}>🚑</div>
          <h1 style={{ fontSize: 22, fontWeight: 700, color: T.navy }}>NEAS QuizPro</h1>
          <p style={{ color: T.sub, fontSize: 14, marginTop: 5 }}>Paramedic Apprenticeship Interview Prep</p>
        </div>

        <Card style={{ padding: 28 }}>
          {/* Tab toggle */}
          <div style={{ display: 'flex', background: T.bg, borderRadius: 6, padding: 3, marginBottom: 22, border: `1px solid ${T.border}` }}>
            {(['login', 'register'] as const).map(m => (
              <button key={m} onClick={() => { setMode(m); setErr('') }} style={{
                flex: 1, padding: '8px 0', borderRadius: 5, border: 'none', fontFamily: 'inherit',
                fontSize: 13, fontWeight: 600, cursor: 'pointer', transition: 'all .15s',
                background: mode === m ? '#fff' : 'transparent',
                color: mode === m ? T.navy : T.muted,
                boxShadow: mode === m ? '0 1px 3px rgba(0,0,0,.08)' : 'none',
              }}>
                {m === 'login' ? 'Sign In' : 'Create Account'}
              </button>
            ))}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {mode === 'register' && (
              <TextInput label="Full Name" value={name} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)} placeholder="e.g. Alex Smith" />
            )}
            <TextInput label="Email Address" type="email" value={email} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEmail(e.target.value)} placeholder="you@neas.nhs.uk" />
            <TextInput
              label="Password" type="password" value={pass}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPass(e.target.value)}
              placeholder="••••••••"
              onKeyDown={(e: React.KeyboardEvent) => e.key === 'Enter' && submit()}
            />
            {err && <p style={{ color: T.red, fontSize: 13, marginTop: -6 }}>{err}</p>}
            <Btn onClick={submit} full size="lg" style={{ marginTop: 4 }}>
              {mode === 'login' ? 'Sign In' : 'Create Account'}
            </Btn>
          </div>
        </Card>

        <p style={{ textAlign: 'center', color: T.muted, fontSize: 12, marginTop: 14 }}>
          Register with any email · Admin access pre-configured
        </p>
      </div>
    </div>
  )
}
