'use client'

import { T } from '@/lib/theme'
import type { Question, Answer } from '@/lib/types'
import { Btn, Card, Pill } from '@/components/ui'

interface QuizResult {
  topic: string
  questions: Question[]
  answers: Record<string, Answer>
  score: number
}

export default function ResultsScreen({ result, onHome }: { result: QuizResult; onHome: () => void }) {
  const { topic, questions, answers, score } = result
  const total   = questions.length
  const correct = Object.values(answers).filter(a => a.correct).length
  const pct     = total > 0 ? Math.round((score / total) * 100) : 0
  const pColor  = pct >= 70 ? T.green : pct >= 45 ? T.amber : T.red
  const msg     = pct >= 80 ? 'Excellent — strong interview preparation.'
                : pct >= 60 ? 'Good effort. Review the gaps below before your interview.'
                : pct >= 40 ? 'Keep studying. Use the explanations to focus your revision.'
                : 'Significant revision needed. Work through each explanation carefully.'

  return (
    <div style={{ minHeight: '100vh', background: T.bg }}>
      {/* Header */}
      <div style={{ background: T.navy, color: '#fff', padding: '28px 24px 32px' }}>
        <div style={{ maxWidth: 720, margin: '0 auto' }}>
          <button onClick={onHome} style={{ background: 'none', border: 'none', color: '#ffffff55', cursor: 'pointer', fontSize: 13, fontFamily: 'inherit', padding: 0, marginBottom: 18 }}>
            ← Back to Dashboard
          </button>
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 24, flexWrap: 'wrap' }}>
            <div>
              <div style={{ fontSize: 60, fontWeight: 700, fontFamily: T.mono, color: pColor, lineHeight: 1 }}>{pct}%</div>
              <div style={{ color: '#ffffffaa', fontSize: 14, marginTop: 6 }}>{correct} / {total} correct · {topic}</div>
            </div>
            <div style={{ background: '#ffffff15', borderRadius: 8, padding: '12px 16px', maxWidth: 320, marginBottom: 4 }}>
              <p style={{ fontSize: 14, color: '#ffffffcc', lineHeight: 1.5 }}>{msg}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Breakdown */}
      <div style={{ maxWidth: 720, margin: '0 auto', padding: '28px 20px 60px' }}>
        <h3 style={{ fontSize: 15, fontWeight: 700, color: T.navy, marginBottom: 16 }}>Question Breakdown</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {questions.map((q, i) => {
            const a     = answers[q.id]
            const ok    = !!a?.correct
            const qCol  = ok ? T.green  : T.red
            const qBg   = ok ? T.greenBg : T.redBg
            const qBd   = ok ? T.greenBd : T.redBd
            return (
              <Card key={q.id} style={{ border: `1px solid ${qBd}`, overflow: 'hidden', animation: `fadeUp ${.3 + i * .04}s ease` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 16px', background: qBg, borderBottom: `1px solid ${qBd}` }}>
                  <span style={{ fontSize: 12, fontFamily: T.mono, color: qCol, fontWeight: 700 }}>Q{i + 1} · {q.type === 'multiple_choice' ? 'MC' : 'SA'}</span>
                  <Pill color={qCol} bg={qBg}>{ok ? 'Correct' : 'Incorrect'}</Pill>
                </div>
                <div style={{ padding: '14px 16px' }}>
                  <p style={{ fontSize: 14, fontWeight: 600, color: T.text, marginBottom: 10, lineHeight: 1.5 }}>{q.question}</p>
                  {a?.answer && <p style={{ fontSize: 13, color: T.sub, marginBottom: 6 }}>Your answer: <em>{a.answer}</em></p>}
                  {!ok && q.answer && <p style={{ fontSize: 13, color: T.green, marginBottom: 6, fontWeight: 500 }}>✓ {q.answer}</p>}
                  {q.explanation && (
                    <div style={{ borderTop: `1px solid ${T.border}`, paddingTop: 10, marginTop: 8 }}>
                      <p style={{ fontSize: 13, color: T.sub, lineHeight: 1.65 }}><strong>Explanation:</strong> {q.explanation}</p>
                    </div>
                  )}
                </div>
              </Card>
            )
          })}
        </div>
        <div style={{ marginTop: 24 }}>
          <Btn onClick={onHome} full size="lg">← Back to Dashboard</Btn>
        </div>
      </div>
    </div>
  )
}
