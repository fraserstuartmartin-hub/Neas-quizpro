'use client'

import { useState, useCallback } from 'react'
import { DB } from '@/lib/storage'
import { T } from '@/lib/theme'
import { TOPICS } from '@/lib/topics'
import type { Session, QuizConfig, TimerMode } from '@/lib/types'
import { Btn, Card, Spinner, Pill, ScoreBadge, TextInput, TopBar } from '@/components/ui'

export default function Dashboard({
  user, onStart, onLogout,
}: {
  user: Session
  onStart: (cfg: QuizConfig) => void
  onLogout: () => void
}) {
  const [tab,         setTab]         = useState<'library' | 'custom' | 'history'>('library')
  const [count,       setCount]       = useState(5)
  const [timer,       setTimer]       = useState<TimerMode>('none')
  const [timerVal,    setTimerVal]    = useState(30)
  const [customTopic, setCustomTopic] = useState('')
  const [launching,   setLaunching]   = useState<string | null>(null)
  const [err,         setErr]         = useState('')

  const progress   = DB.progress()
  const myQuizzes  = Object.entries(progress).filter(([, v]) => v.user === user.email)
  const inProgress = myQuizzes.filter(([, v]) => !v.finished)
  const completed  = myQuizzes.filter(([, v]) => v.finished)

  const launch = useCallback(async (label: string, prompt: string) => {
    setErr('')
    setLaunching(label)
    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topicPrompt: prompt, count }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to generate questions')
      onStart({ quizId: `quiz_${Date.now()}`, topic: label, questions: data.questions, timer, timerVal })
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Could not generate questions')
      setLaunching(null)
    }
  }, [count, timer, timerVal, onStart])

  const resume = (quizId: string) => {
    const p = progress[quizId]
    onStart({ quizId, ...p, resume: true })
  }

  const TABS = [
    { id: 'library' as const, label: 'Topic Library' },
    { id: 'custom'  as const, label: 'Custom Topic' },
    { id: 'history' as const, label: `My History${completed.length > 0 ? ` (${completed.length})` : ''}` },
  ]

  return (
    <div style={{ minHeight: '100vh', background: T.bg, display: 'flex', flexDirection: 'column' }}>
      <TopBar name={user.name} onLogout={onLogout} />

      {/* Settings bar */}
      <div style={{ background: T.surface, borderBottom: `1px solid ${T.border}`, padding: '10px 24px', display: 'flex', flexWrap: 'wrap', gap: 10, alignItems: 'center' }}>
        <span style={{ fontSize: 11, fontWeight: 700, color: T.muted, letterSpacing: '.06em', textTransform: 'uppercase', marginRight: 4 }}>Settings</span>

        <div style={{ position: 'relative' }}>
          <select value={count} onChange={e => setCount(Number(e.target.value))} style={{ background: '#fff', border: `1px solid ${T.border}`, borderRadius: 6, padding: '7px 32px 7px 12px', color: T.text, fontFamily: 'inherit', fontSize: 13, fontWeight: 500, outline: 'none', cursor: 'pointer' }}>
            {[3, 5, 8, 10].map(n => <option key={n} value={n}>{n} Questions</option>)}
          </select>
          <span style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none', color: T.muted, fontSize: 10 }}>▾</span>
        </div>

        <div style={{ position: 'relative' }}>
          <select value={timer} onChange={e => setTimer(e.target.value as TimerMode)} style={{ background: '#fff', border: `1px solid ${T.border}`, borderRadius: 6, padding: '7px 32px 7px 12px', color: T.text, fontFamily: 'inherit', fontSize: 13, fontWeight: 500, outline: 'none', cursor: 'pointer' }}>
            <option value="none">No Timer</option>
            <option value="per_question">Per Question</option>
            <option value="overall">Overall Timer</option>
          </select>
          <span style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none', color: T.muted, fontSize: 10 }}>▾</span>
        </div>

        {timer !== 'none' && (
          <input type="number" min={1} value={timerVal} onChange={e => setTimerVal(Number(e.target.value))}
            placeholder={timer === 'per_question' ? 'secs' : 'mins'}
            style={{ width: 70, background: '#fff', border: `1px solid ${T.border}`, borderRadius: 6, padding: '7px 10px', color: T.text, fontFamily: 'inherit', fontSize: 13, outline: 'none' }}
          />
        )}

        {launching && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: T.accent, fontSize: 13, marginLeft: 4 }}>
            <Spinner size={14} /> <span>Generating <strong>{launching}</strong>…</span>
          </div>
        )}
      </div>

      <div style={{ maxWidth: 960, width: '100%', margin: '0 auto', padding: '28px 20px 80px' }}>

        {/* Resume banner */}
        {inProgress.length > 0 && (
          <div style={{ background: T.amberBg, border: `1px solid ${T.amberBd}`, borderRadius: 8, padding: '12px 16px', marginBottom: 20, display: 'flex', flexWrap: 'wrap', gap: 8, alignItems: 'center' }}>
            <span style={{ fontSize: 13, fontWeight: 600, color: T.amber }}>⏸ Resume:</span>
            {inProgress.map(([id, v]) => (
              <button key={id} onClick={() => resume(id)} style={{ background: '#fff', border: `1px solid ${T.amberBd}`, borderRadius: 5, padding: '4px 12px', fontSize: 12, fontWeight: 600, color: T.amber, cursor: 'pointer', fontFamily: 'inherit' }}>
                {v.topic} — Q{v.currentIndex + 1}/{v.questions.length}
              </button>
            ))}
          </div>
        )}

        {/* Tabs */}
        <div style={{ display: 'flex', borderBottom: `2px solid ${T.border}`, marginBottom: 24 }}>
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{ padding: '10px 20px', border: 'none', background: 'transparent', fontFamily: 'inherit', fontSize: 14, fontWeight: 600, cursor: 'pointer', transition: 'all .15s', color: tab === t.id ? T.accent : T.muted, borderBottom: tab === t.id ? `2px solid ${T.accent}` : '2px solid transparent', marginBottom: -2 }}>
              {t.label}
            </button>
          ))}
        </div>

        {err && <div style={{ background: T.redBg, border: `1px solid ${T.redBd}`, borderRadius: 7, padding: '10px 16px', marginBottom: 16, color: T.red, fontSize: 13 }}>⚠ {err}</div>}

        {/* LIBRARY */}
        {tab === 'library' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 26, animation: 'fadeUp .35s ease' }}>
            {TOPICS.map(cat => (
              <div key={cat.category}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                  <span style={{ display: 'inline-block', width: 3, height: 14, background: cat.accent, borderRadius: 2 }} />
                  <h3 style={{ fontSize: 11, fontWeight: 700, color: T.sub, textTransform: 'uppercase', letterSpacing: '.08em' }}>{cat.category}</h3>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(230px,1fr))', gap: 8 }}>
                  {cat.items.map(item => {
                    const isThis = launching === item.label
                    return (
                      <button key={item.label}
                        onClick={() => !launching && launch(item.label, item.prompt)}
                        disabled={!!launching}
                        style={{ background: '#fff', border: `1px solid ${T.border}`, borderRadius: 7, padding: '13px 16px', textAlign: 'left', fontFamily: 'inherit', cursor: launching ? 'not-allowed' : 'pointer', transition: 'all .15s', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, opacity: launching && !isThis ? .5 : 1 }}
                        onMouseEnter={e => { if (!launching) { (e.currentTarget as HTMLButtonElement).style.borderColor = cat.accent; (e.currentTarget as HTMLButtonElement).style.boxShadow = `0 0 0 3px ${cat.accent}18` } }}
                        onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.borderColor = T.border; (e.currentTarget as HTMLButtonElement).style.boxShadow = 'none' }}
                      >
                        <span style={{ fontSize: 13, fontWeight: 600, color: T.text, lineHeight: 1.4 }}>{item.label}</span>
                        {isThis ? <Spinner size={15} color={cat.accent} /> : <span style={{ color: cat.accent, fontSize: 14, flexShrink: 0 }}>→</span>}
                      </button>
                    )
                  })}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* CUSTOM */}
        {tab === 'custom' && (
          <div style={{ maxWidth: 520, animation: 'fadeUp .35s ease' }}>
            <p style={{ color: T.sub, fontSize: 14, marginBottom: 20, lineHeight: 1.6 }}>Enter any topic and the AI will generate apprenticeship-level questions tailored for your NEAS interview prep.</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <TextInput label="Topic or Subject" value={customTopic} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCustomTopic(e.target.value)}
                placeholder="e.g. Why I want to be a paramedic, Stroke recognition…"
                onKeyDown={(e: React.KeyboardEvent) => e.key === 'Enter' && customTopic.trim() && !launching && launch(customTopic.trim(), customTopic.trim())}
              />
              <Btn onClick={() => launch(customTopic.trim(), customTopic.trim())} disabled={!!launching || !customTopic.trim()} size="lg" style={{ alignSelf: 'flex-start' }}>
                {launching ? <><Spinner color="#fff" size={16} /> Generating…</> : 'Generate Quiz →'}
              </Btn>
            </div>
          </div>
        )}

        {/* HISTORY */}
        {tab === 'history' && (
          <div style={{ animation: 'fadeUp .35s ease' }}>
            {completed.length === 0 && inProgress.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '60px 20px', color: T.muted }}>
                <div style={{ fontSize: 36, marginBottom: 12 }}>📋</div>
                <p style={{ fontSize: 15, fontWeight: 600, color: T.sub }}>No history yet</p>
                <p style={{ fontSize: 13, marginTop: 6 }}>Pick a topic from the library to get started.</p>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {[...completed].reverse().map(([id, v]) => {
                  const pct = v.score != null ? Math.round((v.score / v.questions.length) * 100) : 0
                  return (
                    <Card key={id} style={{ padding: '14px 18px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
                      <div>
                        <div style={{ fontWeight: 600, fontSize: 14 }}>{v.topic}</div>
                        <div style={{ fontSize: 12, color: T.muted, marginTop: 2 }}>{v.questions.length} questions</div>
                      </div>
                      <ScoreBadge pct={pct} />
                    </Card>
                  )
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
