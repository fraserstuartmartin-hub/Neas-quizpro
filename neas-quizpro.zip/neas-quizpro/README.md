# NEAS QuizPro — Deployment Guide

AI-powered paramedic apprenticeship interview prep platform for NEAS.

---

## Quick Deploy to Vercel (5 minutes)

### 1. Install dependencies locally (optional — just to verify it builds)
```bash
npm install
npm run build
```

### 2. Push to GitHub
```bash
git init
git add .
git commit -m "Initial NEAS QuizPro"
git remote add origin https://github.com/YOUR_USERNAME/neas-quizpro.git
git push -u origin main
```

### 3. Deploy on Vercel
1. Go to [vercel.com](https://vercel.com) and sign in
2. Click **Add New → Project**
3. Import your GitHub repo
4. Under **Environment Variables**, add:

| Variable | Value |
|---|---|
| `ANTHROPIC_API_KEY` | Your Anthropic API key (from console.anthropic.com) |
| `NEXT_PUBLIC_ADMIN_EMAIL` | `fraser.stuart.martin@gmail.com` |
| `NEXT_PUBLIC_ADMIN_PASSWORD` | `admin1234` ← **change this!** |
| `NEXT_PUBLIC_ADMIN_NAME` | `Fraser Martin` |

5. Click **Deploy**

That's it — Vercel handles the build and hosting automatically.

---

## Admin Login
- **Email:** fraser.stuart.martin@gmail.com  
- **Password:** admin1234 (change via env var before going live)

---

## Project Structure
```
neas-quizpro/
├── app/
│   ├── layout.tsx          # Root layout + global styles
│   ├── page.tsx            # Auth gate + screen router
│   └── api/
│       ├── generate/route.ts  # ← AI question generation (server-side, key protected)
│       └── grade/route.ts     # ← AI answer grading (server-side, key protected)
├── components/
│   ├── ui.tsx              # Shared UI primitives
│   ├── AuthScreen.tsx
│   ├── Dashboard.tsx
│   ├── QuizScreen.tsx
│   ├── ResultsScreen.tsx
│   └── AdminDashboard.tsx
└── lib/
    ├── types.ts            # TypeScript interfaces
    ├── theme.ts            # Colour tokens
    ├── storage.ts          # localStorage helpers
    └── topics.ts           # 30+ topic library
```

## Security Notes
- The Anthropic API key is **never** sent to the browser — all AI calls go through `/api/generate` and `/api/grade`
- User data is stored in the browser's localStorage (no backend database required)
- For a production multi-user setup, replace localStorage with a database (e.g. Supabase, PlanetScale)

## Local Development
```bash
cp .env.example .env.local
# Fill in your ANTHROPIC_API_KEY in .env.local
npm install
npm run dev
# Open http://localhost:3000
```
